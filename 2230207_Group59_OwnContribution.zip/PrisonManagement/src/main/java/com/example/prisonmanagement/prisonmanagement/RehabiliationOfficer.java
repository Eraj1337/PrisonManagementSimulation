package com.example.prisonmanagement.prisonmanagement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class RehabiliationOfficer {

    @FXML
    void conductSession(ActionEvent event) {

    }

    @FXML
    void famiyInformation(ActionEvent event) {

    }

    @FXML
    void sessionActivities(ActionEvent event) {

    }

    @FXML
    void viewPrisonRecord(ActionEvent event) {

    }

}
