package com.example.prisonmanagement.prisonmanagement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class MaintenanceStaffController{

    @FXML
    void enterButtonClick(ActionEvent event) {

    }

    @FXML
    void optionsComboBoxClick(ActionEvent event) {

    }

    @FXML
    void submitReportButtonClick(ActionEvent event) {

    }

    @FXML
    void viewReportButtonClick(ActionEvent event) {

    }

}
