package com.example.prisonmanagement.prisonmanagement;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.input.MouseEvent;

public class SessionActivites {

    @FXML
    private TableView<?> activitiesTableView;

    @FXML
    private TableColumn<?, ?> sessionDateColumn;

    @FXML
    private TableColumn<?, ?> sessionEnrolledColumn;

    @FXML
    private TableColumn<?, ?> sessionNameColumn;

    @FXML
    void sessionBtn(ActionEvent event) {

    }

    @FXML
    void sessionTextArea(MouseEvent event) {

    }

}
