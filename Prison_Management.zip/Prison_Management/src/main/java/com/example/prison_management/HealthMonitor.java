package com.example.prison_management;

import javafx.event.ActionEvent;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class HealthMonitor
{
    @javafx.fxml.FXML
    private TextField idtextfield;
    @javafx.fxml.FXML
    private CheckBox femaleCheckBox;
    @javafx.fxml.FXML
    private ComboBox healthCheckComboBox;
    @javafx.fxml.FXML
    private TextField nametextfield;
    @javafx.fxml.FXML
    private CheckBox maleCheckBox;
    @javafx.fxml.FXML
    private TextField agetextfield;
    @javafx.fxml.FXML
    private ComboBox healthRecordComboBox;

    @javafx.fxml.FXML
    public void initialize() {
    }

    @javafx.fxml.FXML
    public void logoutOnActionButton(ActionEvent actionEvent) {
    }

    @javafx.fxml.FXML
    public void backButtonOnAction(ActionEvent actionEvent)  throws IOException {
        SceneSwitcher.switchScene("Officer-DashBoard.fxml",actionEvent,"DashBoard");
    }
}