package com.example.prison_management;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class VisitorController {

    @FXML
    void bookScheduleButton(ActionEvent event) {

    }

    @FXML
    void feedbackButton(ActionEvent event) {

    }

    @FXML
    void rulesRegulationsButton(ActionEvent event) {

    }

    @FXML
    void viewInmateInfoButton(ActionEvent event) {

    }

    @FXML
    void viewScheduledVisitsButton(ActionEvent event) {

    }

}
