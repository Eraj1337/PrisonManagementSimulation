package com.example.prison_management;

public class EmergencyResponse {
}
