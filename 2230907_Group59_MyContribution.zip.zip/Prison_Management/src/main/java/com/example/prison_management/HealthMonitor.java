import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

public class HealthMonitor {

    @FXML
    private TextField agetextfield;

    @FXML
    private CheckBox femaleCheckBox;

    @FXML
    private ComboBox<?> healthCheckComboBox;

    @FXML
    private ComboBox<?> healthRecordComboBox;

    @FXML
    private TextField idtextfield;

    @FXML
    private CheckBox maleCheckBox;

    @FXML
    private TextField nametextfield;

    @FXML
    void backButton(ActionEvent event) {

    }

    @FXML
    void logoutOnActionButton(ActionEvent event) {

    }

}
