package com.example.prison_management;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class OfficerDashboard {

    @FXML
    void SupportButtononclick(ActionEvent event) {

    }

    @FXML
    void emergencyResponsButtononclick(ActionEvent event) {

    }

    @FXML
    void healthMonitorButtononclick(ActionEvent event) {

    }

    @FXML
    void programButtononclickm(ActionEvent event) {

    }

    @FXML
    void treatmentButtononclick(ActionEvent event) {

    }

}
