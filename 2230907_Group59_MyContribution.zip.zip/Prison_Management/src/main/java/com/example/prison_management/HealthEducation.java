package com.example.prison_management;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class HealthEducation {

    @FXML
    private DatePicker dateDatePicker;

    @FXML
    private TextField timeTextField;

    @FXML
    private TextField topicTextField;

    @FXML
    void backButton(ActionEvent event) {

    }

    @FXML
    void healthEduButton(ActionEvent event) {

    }

    @FXML
    void logoutButton(ActionEvent event) {

    }

    @FXML
    void workshopButton(ActionEvent event) {

    }

}
