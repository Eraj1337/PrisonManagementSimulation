package com.example.prison_management;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class MedicalOfficer {

    @FXML
    private TextField passwordTextField;

    @FXML
    private TextField userIdtextField;

    @FXML
    void forgetPassButtononclick(ActionEvent event) {

    }

    @FXML
    void loginButtononclick(ActionEvent event) {

    }

}
